require_relative './game'

game = Game.new
game.begin_game
