class HelloController < ApplicationController
  def dolly
  end
end
