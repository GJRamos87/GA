class Album < ActiveRecord::Base
end
