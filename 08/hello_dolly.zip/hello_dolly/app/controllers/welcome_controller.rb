class WelcomeController < ApplicationController
  def dolly
  end
end
