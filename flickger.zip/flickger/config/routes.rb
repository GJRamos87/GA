Rails.application.routes.draw do
  resources :photos
end
