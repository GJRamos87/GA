class FarewellController < ApplicationController
  def roger
  end
end
